'use strict'
  
// This placeholder script allows this package to be discovered using require.resolve.
// It may be used in the future to export information about the files in this UI.
